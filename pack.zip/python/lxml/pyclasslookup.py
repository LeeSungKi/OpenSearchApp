# dummy module for backwards compatibility

from lxml.etree import PythonElementClassLookup
